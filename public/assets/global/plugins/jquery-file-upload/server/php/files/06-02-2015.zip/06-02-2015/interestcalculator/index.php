
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<h1>Simple Interest Calculator</h1>
<form action="index.php" method="post">
    Principal Amount: <input type="text" name="priAmount"><br>
    Annual Interest Rate: <input type="text" name="intRate">%<br>
    Time Period: <input type="text" name="timePeriod">Year<br>
    <input type="submit" value="Calculate" name="submit">
</form>
</body>
</html>

<?php
    require 'interestCalculator.php';
    if (isset($_POST["priAmount"]) && isset($_POST["intRate"]) &&isset($_POST["timePeriod"])) {
        $intCalc = new interestCalculator();
        $intCalc->priAmount = $_POST["priAmount"];
        $intCalc->intRate = $_POST["intRate"];
        $intCalc->timePeriod = $_POST["timePeriod"];

        echo "Result: ".$intCalc->getTotalAmount();
    }
?>