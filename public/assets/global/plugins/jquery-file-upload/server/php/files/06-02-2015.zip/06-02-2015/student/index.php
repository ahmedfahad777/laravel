
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<form action="index.php" method="post">
    First Name:<input type="text" name="firstName"><br>
    Last Name:<input type="text" name="lastName"><br>
    Reg No:<input type="text" name="regNo"><br>
    <input type="submit" value="Show Below" name="submit">
</form>
</body>
</html>

<?php
    require 'Student.php';
    if (isset($_POST["firstName"]) && isset($_POST["lastName"]) &&isset($_POST["regNo"]))
    {
        $aStudent = new Student();
        $aStudent->firstName = $_POST["firstName"];
        $aStudent->lastName = $_POST["lastName"];
        $aStudent->regNo = $_POST["regNo"];
        echo "Full Name: ".$aStudent->getFullName(). " Reg No:" . $aStudent->regNo;
    }
?>