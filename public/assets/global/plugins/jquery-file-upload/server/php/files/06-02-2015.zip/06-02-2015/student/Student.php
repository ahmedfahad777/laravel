<?php

class Student {
    public $firstName;
    public $lastName;
    public $regNo;

    public function getFullName(){
        return $this->firstName." ".$this->lastName;
    }
}