<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LunchBill</title>
</head>
<body>
<h1>Lunch Bill Calculation UI</h1>

<form action="index.php" method="post">
    Rice: <input type="text" name="rice"/> Unit. (20tk/Unit)<br/>
    Vegetable: <input type="text" name="vegetable"/>Unit. (30tk/Unit)<br/>
    Fish: <input type="text" name="fish"/>Unit. (80tk/Unit)<br/>
    Meat: <input type="text" name="meat"/>Unit. (120tk/Unit)<br/>
    VAT: <input type="text" name="vat"/> % of Gross total<br />
    <input type="submit" value="Show Bill" name="submit"/>
</form>
</body>
</html>

<?php
    require_once 'lunchCalc.php';

    if (isset($_POST["rice"]) && isset($_POST["vegetable"]) && isset($_POST["fish"]) && isset($_POST["meat"]) && isset($_POST["vat"])) {
        $lunchCalc1 = new lunchCalc();
        $lunchCalc1->rice=$_POST['rice'];
        $lunchCalc1->vegetable=$_POST['vegetable'];
        $lunchCalc1->fish=$_POST['fish'];
        $lunchCalc1->meat=$_POST['meat'];
        $lunchCalc1->vat=$_POST['vat'];

        echo "Gross Total: ".$lunchCalc1->getGrossTotal()."<br />";
        echo "Payable Amount: ".$lunchCalc1->getPayableAmount();
    }
?>