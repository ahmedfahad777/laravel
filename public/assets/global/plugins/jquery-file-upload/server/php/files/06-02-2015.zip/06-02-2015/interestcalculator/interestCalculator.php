<?php

class interestCalculator {
    public $priAmount;
    public $intRate;
    public $timePeriod;

    public function getTotalAmount(){
        $interest=($this->priAmount*$this->intRate*$this->timePeriod)/100;
        //return (($this->priAmount*$this->intRate*$this->timePeriod)/100)+$this->priAmount;
        return $interest+$this->priAmount;
    }
}