<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 2/6/15
 * Time: 3:26 PM
 */

class lunchCalc {
    public $rice;
    public $vegetable;
    public $fish;
    public $meat;
    public $vat;

    public function getGrossTotal(){
        $grossTotal = $this->rice*20 + $this->vegetable*30 + $this->fish*80 + $this->meat*120;
        return $grossTotal;
    }

    public function getPayableAmount(){

        return ($this->getGrossTotal() * $this->vat )/100 + $this->getGrossTotal();
    }

}