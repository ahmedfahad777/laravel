<?php

class Employee {
    public $id;
    public $name;
    public $salary;
}